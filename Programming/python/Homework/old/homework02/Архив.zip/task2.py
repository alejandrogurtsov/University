l=[int(x) for x in input().split()]
print(max(l)-min(l))